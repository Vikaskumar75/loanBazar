package com.instantloans.loanguides

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
